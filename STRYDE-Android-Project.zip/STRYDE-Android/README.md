# STRYDE Android project

This is an Android Studio project for the STRYDE activity tracker.

## Included
- Dark, cyan fitness dashboard
- Walking distance entry and calorie estimate
- Cycling distance + duration, average speed and calorie estimate
- Editable daily goals and progress bars
- Android phone step-counter integration when the device has a compatible hardware sensor and Activity Recognition permission is granted
- Offline local storage for entered activity data

## Build an APK
1. Install Android Studio on a computer.
2. Open this `STRYDE-Android` folder in Android Studio.
3. Allow Gradle sync to finish (internet may be required to download Android build tools).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location under `app/build/outputs/apk/debug/`.

This workspace does not include the Android SDK/Gradle build environment, so the APK itself has not been compiled here.

## Notes
- The phone step sensor reports cumulative steps since the last reboot; this starter app uses a simple in-memory baseline and is a prototype, not a production-grade midnight-reset/history implementation.
- Cycling is manually entered in this first version. GPS ride tracking, route maps, persistent daily history, and a polished launcher icon are future upgrades.
- Calorie values are rough illustrative estimates, not individualized measurements.
